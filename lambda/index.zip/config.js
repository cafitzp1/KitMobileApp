'use strict';

const config = {
    user: "cafitzp1",
    password: "cafi5859",
    host: "52.42.131.91",
    database: "db_test_cafitzp1",
    timeout: "db_test_cafitzp1"
};

module.exports = config;