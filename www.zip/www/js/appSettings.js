'use strict';

const appSettings = {
    googleAPIKey: "AIzaSyA7QhvnYjciKGDDYCqQIMa7jAQqXC33cFg",
    apigURL: "https://ngd03fm3w2.execute-api.us-west-2.amazonaws.com/default/kit-mobile"
};